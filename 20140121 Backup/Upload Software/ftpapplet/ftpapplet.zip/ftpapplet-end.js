// write out ending applet tag
document.write("</applet>");